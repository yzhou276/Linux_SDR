i2cset -y 0 26 30 0
i2cset -y 0 26 12 0x37
i2cset -y 0 26 0 0x80
i2cset -y 0 26 2 0x80
i2cset -y 0 26 4 0x79
i2cset -y 0 26 6 0x79
i2cset -y 0 26 8 0x10
i2cset -y 0 26 10 0
i2cset -y 0 26 14 2
i2cset -y 0 26 16 0
i2cset -y 0 26 12 0x27
i2cset -y 0 26 18 0x1

